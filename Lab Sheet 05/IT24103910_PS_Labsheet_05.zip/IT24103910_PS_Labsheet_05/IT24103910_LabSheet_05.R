getwd()
setwd("C:\\Users\\Geenuth\\2nd Year 1st Semester\\Probability and Statistics(IT2120)\\Practical\\Lab 5")

#Question 01
Delivery_Times <- read.table("Exercise - Lab 05.txt",header=TRUE,sep = ",")
fix(Delivery_Times)

#Question 02
histogram <- hist(Delivery_Time_.minutes., main = "Histogram for Delivery Times",breaks = seq(20, 70, length.out = 9), right = TRUE)

#Question 03
"The histogram displays a distribution that is roughly symmetric and bell-shaped, indicating a possible normal or near-normal distribution. The highest frequency occurs around 40-50 minutes, with the frequency tapering off evenly on both sides toward 20 and 70 minutes. This suggests a unimodal distribution with a slight potential for skewness, but it generally aligns with a normal pattern."

#Question 04
breaks <- round(histogram$breaks)
freq <- histogram$counts
mids <- histogram$mids
cum.freq <- cumsum(freq)

new <- c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i] = 0
  } else {
    new[i] = cum.freq[i-1]
  }
}

plot(breaks,new,type = 'l', main = "Cumulative Frequency Polygon for Delivery Time", xlab = "Cumulative Frequency",ylab = "Delivery Time", ylim = c(0,max(cum.freq)))
cbind(Upper = breaks,CumFreq = new)
